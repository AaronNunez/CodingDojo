package com.codingdojo.hoppersreceipt;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ReceiptController {

    @RequestMapping("/")
    public String index(Model model) {
        
        String name = "Aaron Nunez";
        String itemName = "Burger";
        double itemPrice = 5.25;
        String itemDescription = "Good Burger";
        String itemVendor = "Burger Store";
    
        model.addAttribute("name", name);
        model.addAttribute("itemName", itemName);
        model.addAttribute("itemPrice", itemPrice);
        model.addAttribute("itemDescription", itemDescription);
        model.addAttribute("itemVendor", itemVendor);
    	// Your code here! Add values to the view model to be rendered
    
        return "index.jsp";
    }
}
