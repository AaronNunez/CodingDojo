// Create a BankAccount class.
class BankAccount{

    // The class should have the following attributes: (double) checking balance, (double) savings balance.
    private double checkingBalance;
    private double savingsBalance;

    // Create a class member (static) that has the number of accounts created thus far.
    public static int numOfAccounts = 0;

    // Create a class member (static) that tracks the total amount of money stored in every account created.
    public static double totalAmount = 0;
    
    public BankAccount(){
        // In the constructor, be sure to increment the account count.
        BankAccount.numOfAccounts +=1;
        this.checkingBalance = 0;
		this.savingsBalance = 0;
    }

    // Create a getter method for the user's checking account balance.
    public double getCheckingBalance() {
        return this.checkingBalance;}

    // Create a getter method for the user's saving account balance.
    public double getSavingsBalance(){
        return this.savingsBalance;
    }


    // Create a method that will allow a user to deposit money into either the checking or saving, be sure to add to total amount stored.
    public void deposit(double amount, String account ){
        if (account == "checking"){
            this.checkingBalance += amount;
        }
        else {
            this.savingsBalance += amount;
        }
        this.totalAmount += amount;
    }



    // Create a method to withdraw money from one balance. Do not allow them to withdraw money if there are insufficient funds.
    public void withdraw(double amount, String account ){
        if (account == "checking"){
            if(amount > this.checkingBalance){
                System.out.println("Insufficient Funds");
                return;
            }
            this.checkingBalance -= amount;
        }
        else {
            if(amount > this.savingsBalance){
                System.out.println("Insufficient Funds");
                return;
            }
            this.savingsBalance -= amount;
        }
        this.totalAmount -= amount;
    }

    // Create a method to see the total money from the checking and saving.
	public void displayCheckingBalance(){
		System.out.printf(String.format("Checking: %s", this.checkingBalance));
	}

    public void displaySavingsBalance() {
		System.out.printf(String.format("Savings: %s", this.savingsBalance));
	}



}
